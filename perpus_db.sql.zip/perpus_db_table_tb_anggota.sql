
-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_anggota`
--

CREATE TABLE `tb_anggota` (
  `NoAnggota` int(11) NOT NULL,
  `Nama` varchar(40) NOT NULL,
  `Alamat` varchar(80) NOT NULL,
  `Jenis` varchar(40) NOT NULL,
  `Judul` varchar(40) NOT NULL,
  `Pinjam` date NOT NULL,
  `Kembali` date NOT NULL,
  `Status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_anggota`
--

INSERT INTO `tb_anggota` (`NoAnggota`, `Nama`, `Alamat`, `Jenis`, `Judul`, `Pinjam`, `Kembali`, `Status`) VALUES
(124, 'Lutful', 'Malang', 'Pelajaran', 'Android', '2017-03-17', '2017-03-20', 'Pinjam');
